var   classfiy = [{
            name: "施华蔻",
            content: [{
                title: "洗发类",
                itemecon: [{
                    name: "护亮泽洗发水",
                    src: "../../static/classify/1.jpg",
                    id: "1",
                    tol: "520ml*瓶",
                    price: "123.00",
                    pinglun: 3625,
                    num: 1,
                    check: false,
                    floatLeft: false
                  },
                  {
                    name: "滋养洗发水",
                    src: "../../static/classify/2.jpg",
                    id: "2",
                    tol: "520ml*瓶",
                    price: "123.00",
                    pinglun: 3625,
                    num: 1,
                    check: false,
                    floatLeft: false
                  },
                  {
                    name: "柔顺洗发露",
                    src: "../../static/classify/3.jpg",
                    id: "3",
                    tol: "520ml*瓶",
                    price: "123.00",
                    pinglun: 3625,
                    num: 1,
                    check: false,
                    floatLeft: false
                  },
                  {
                    name: "去屑洗发露",
                    src: "../../static/classify/4.jpg",
                    id: "4",
                    tol: "520ml*瓶",
                    price: "123.00",
                    pinglun: 3625,
                    num: 1,
                    check: false,
                    floatLeft: false
                  },
                  {
                    name: "柔顺洗发露",
                    src: "../../static/classify/5.jpg",
                    id: "5",
                    tol: "520ml*瓶",
                    price: "123.00",
                    pinglun: 3625,
                    num: 1,
                    check: false,
                    floatLeft: false
                  },
                  {
                    name: "焕彩洗发水",
                   src: "../../static/classify/6.jpg",
                    id: "6",
                    tol: "520ml*瓶",
                    price: "123.00",
                    pinglun: 3625,
                    num: 1,
                    check: false,
                    floatLeft: false
                  }
                ]
              },
              {
                title: "染发类",
                itemecon: [{
                    name: "施华蔻染色",
                    src: "../../static/classify/7.jpg",
                    id: "7",
                    tol: "520ml*瓶",
                    price: "123.00",
                    pinglun: 3625,
                    num: 1,
                    check: false,
                    floatLeft: false
                  },
                  {
                    name: "施华蔻双氧乳",
                    src: "../../static/classify/8.jpg",
                    id: "8",
                    tol: "520ml*瓶",
                    price: "123.00",
                    pinglun: 3625,
                    num: 1,
                    check: false,
                    floatLeft: false
                  },
                  {
                    name: "施华蔻染发膏",
                    src: "../../static/classify/9.jpg",
                    id: "9",
                    tol: "520ml*瓶",
                    price: "123.00",
                    pinglun: 3625,
                    num: 1,
                    check: false,
                    floatLeft: false
                  }
                ]
              }
            ]
          },
          {
            name: "沙宣",
            content: [{
                title: "沙宣1",
                itemecon: [{
                    name: "护亮泽洗发水",
                    src: "../../static/classify/1.jpg",
                    id: "1",
                    tol: "520ml*瓶",
                    price: "123.00",
                    pinglun: 3625,
                    num: 1,
                    check: false,
                    floatLeft: false
                  },
                  {
                    name: "滋养洗发水",
                    src: "../../static/classify/2.jpg",
                    id: "2",
                    tol: "520ml*瓶",
                    price: "123.00",
                    pinglun: 3625,
                    num: 1,
                    check: false,
                    floatLeft: false
                  },
                  {
                    name: "柔顺洗发露",
                    src: "../../static/classify/3.jpg",
                    id: "3",
                    tol: "520ml*瓶",
                    price: "123.00",
                    pinglun: 3625,
                    num: 1,
                    check: false,
                    floatLeft: false
                  }
                ]
              },
              {
                title: "沙宣2",
                itemecon: [{
                    name: "沙宣染色",
                    src: "../../static/classify/7.jpg",
                    id: "7",
                    tol: "520ml*瓶",
                    price: "123.00",
                    pinglun: 3625,
                    num: 1,
                    check: false,
                    floatLeft: false
                  },
                  {
                    name: "沙宣双氧乳",
                    src: "../../static/classify/8.jpg",
                    id: "8",
                    tol: "520ml*瓶",
                    price: "123.00",
                    pinglun: 3625,
                    num: 1,
                    check: false,
                    floatLeft: false
                  },
                  {
                    name: "沙宣染发膏",
                   src: "../../static/classify/9.jpg",
                    id: "9",
                    tol: "520ml*瓶",
                    price: "123.00",
                    pinglun: 3625,
                    num: 1,
                    check: false,
                    floatLeft: false
                  }
                ]
              }
            ]
          },
          {
            name: "欧莱雅",
            content: [{
                title: "洗发类",
                itemecon: [{
                    name: "护亮泽洗发水",
                   src: "../../static/classify/1.jpg",
                    id: "1",
                    tol: "520ml*瓶",
                    price: "123.00",
                    pinglun: 3625,
                    num: 1,
                    check: false,
                    floatLeft: false
                  },
                  {
                    name: "滋养洗发水",
                   src: "../../static/classify/2.jpg",
                    id: "2",
                    tol: "520ml*瓶",
                    price: "123.00",
                    pinglun: 3625,
                    num: 1,
                    check: false,
                    floatLeft: false
                  },
                  {
                    name: "柔顺洗发露",
                    src: "../../static/classify/3.jpg",
                    id: "3",
                    tol: "520ml*瓶",
                    price: "123.00",
                    pinglun: 3625,
                    num: 1,
                    check: false,
                    floatLeft: false
                  }
                ]
              },
              {
                title: "染发类",
                itemecon: [{
                    name: "沙宣染色",
                    src: "../../static/classify/7.jpg",
                    id: "7",
                    tol: "520ml*瓶",
                    price: "123.00",
                    pinglun: 3625,
                    num: 1,
                    check: false,
                    floatLeft: false
                  },
                  {
                    name: "沙宣双氧乳",
                   src: "../../static/classify/8.jpg",
                    id: "8",
                    tol: "520ml*瓶",
                    price: "123.00",
                    pinglun: 3625,
                    num: 1,
                    check: false,
                    floatLeft: false
                  },
                  {
                    name: "沙宣染发膏",
                   src: "../../static/classify/9.jpg",
                    id: "9",
                    tol: "520ml*瓶",
                    price: "123.00",
                    pinglun: 3625,
                    num: 1,
                    check: false,
                    floatLeft: false
                  }
                ]
              }
            ]
          },
          {
            name: "潘婷",
            content: [{
                title: "潘婷1",
                itemecon: [{
                    name: "护亮泽洗发水",
                    src: "../../static/classify/1.jpg",
                    id: "1",
                    tol: "520ml*瓶",
                    price: "123.00",
                    pinglun: 3625,
                    num: 1,
                    check: false,
                    floatLeft: false
                  },
                  {
                    name: "滋养洗发水",
                    src: "../../static/classify/2.jpg",
                    id: "2",
                    tol: "520ml*瓶",
                    price: "123.00",
                    pinglun: 3625,
                    num: 1,
                    check: false,
                    floatLeft: false
                  }
                ]
              },
              {
                title: "潘婷2",
                itemecon: [{
                    name: "沙宣染色",
                   src: "../../static/classify/7.jpg",
                    id: "7",
                    tol: "520ml*瓶",
                    price: "123.00",
                    pinglun: 3625,
                    num: 1,
                    check: false,
                    floatLeft: false
                  },
                  {
                    name: "沙宣双氧乳",
                   src: "../../static/classify/8.jpg",
                    id: "8",
                    tol: "520ml*瓶",
                    price: "123.00",
                    pinglun: 3625,
                    num: 1,
                    check: false,
                    floatLeft: false
                  },
                  {
                    name: "沙宣染发膏",
                   src: "../../static/classify/9.jpg",
                    id: "9",
                    tol: "520ml*瓶",
                    price: "123.00",
                    pinglun: 3625,
                    num: 1,
                    check: false,
                    floatLeft: false
                  }
                ]
              }
            ]
          },
          {
            name: "资生堂",
            content: [{
                title: "洗发类",
                itemecon: [{
                    name: "护亮泽洗发水",
                    src: "../../static/classify/1.jpg",
                    id: "1",
                    tol: "520ml*瓶",
                    price: "123.00",
                    pinglun: 3625,
                    num: 1,
                    check: false,
                    floatLeft: false
                  },
                  {
                    name: "滋养洗发水",
                    src: "../../static/classify/2.jpg",
                    id: "2",
                    tol: "520ml*瓶",
                    price: "123.00",
                    pinglun: 3625,
                    num: 1,
                    check: false,
                    floatLeft: false
                  },
                  {
                    name: "柔顺洗发露",
                    src: "../../static/classify/3.jpg",
                    id: "3",
                    tol: "520ml*瓶",
                    price: "123.00",
                    pinglun: 3625,
                    num: 1,
                    check: false,
                    floatLeft: false
                  }
                ]
              },
              {
                title: "染发类",
                itemecon: [{
                    name: "沙宣染色",
                    src: "../../static/classify/7.jpg",
                    id: "7",
                    tol: "520ml*瓶",
                    price: "123.00",
                    pinglun: 3625,
                    num: 1,
                    check: false,
                    floatLeft: false
                  },
                  {
                    name: "沙宣双氧乳",
                    src: "../../static/classify/8.jpg",
                    id: "8",
                    tol: "520ml*瓶",
                    price: "123.00",
                    pinglun: 3625,
                    num: 1,
                    check: false,
                    floatLeft: false
                  },
                  {
                    name: "沙宣染发膏",
                    src: "../../static/classify/9.jpg",
                    id: "9",
                    tol: "520ml*瓶",
                    price: "123.00",
                    pinglun: 3625,
                    num: 1,
                    check: false,
                    floatLeft: false
                  }
                ]
              }
            ]
          },
          {
            name: "阿道夫",
            content: [{
                title: "洗发类4",
                itemecon: [{
                    name: "护亮泽洗发水",
                   src: "../../static/classify/1.jpg",
                    id: "1",
                    tol: "520ml*瓶",
                    price: "123.00",
                    pinglun: 3625,
                    num: 1,
                    check: false,
                    floatLeft: false
                  },
                  {
                    name: "滋养洗发水",
                   src: "../../static/classify/2.jpg",
                    id: "2",
                    tol: "520ml*瓶",
                    price: "123.00",
                    pinglun: 3625,
                    num: 1,
                    check: false,
                    floatLeft: false
                  },
                  {
                    name: "柔顺洗发露",
                    src: "../../static/classify/3.jpg",
                    id: "3",
                    tol: "520ml*瓶",
                    price: "123.00",
                    pinglun: 3625,
                    num: 1,
                    check: false,
                    floatLeft: false
                  }
                ]
              },
              {
                title: "染发类4",
                itemecon: [{
                    name: "沙宣染色",
                    src: "../../static/classify/4.jpg",
                    id: "7",
                    tol: "520ml*瓶",
                    price: "123.00",
                    pinglun: 3625,
                    num: 1,
                    check: false,
                    floatLeft: false
                  },
                  {
                    name: "沙宣双氧乳",
                    src: "../../static/classify/5.jpg",
                    id: "8",
                    tol: "520ml*瓶",
                    price: "123.00",
                    pinglun: 3625,
                    num: 1,
                    check: false,
                    floatLeft: false
                  },
                  {
                    name: "沙宣染发膏",
                    src: "../../static/classify/9.jpg",
                    id: "9",
                    tol: "520ml*瓶",
                    price: "123.00",
                    pinglun: 3625,
                    num: 1,
                    check: false,
                    floatLeft: false
                  }
                ]
              }
            ]
          },
          {
            name: "卡诗",
            content: [{
                title: "洗发类",
                itemecon: [{
                    name: "护亮泽洗发水",
                    src: "../../static/classify/1.jpg",
                    id: "1",
                    tol: "520ml*瓶",
                    price: "123.00",
                    pinglun: 3625,
                    num: 1,
                    check: false,
                    floatLeft: false
                  },
                  {
                    name: "滋养洗发水",
                    src: "../../static/classify/2.jpg",
                    id: "2",
                    tol: "520ml*瓶",
                    price: "123.00",
                    pinglun: 3625,
                    num: 1,
                    check: false,
                    floatLeft: false
                  },
                  {
                    name: "柔顺洗发露",
                   src: "../../static/classify/3.jpg",
                    id: "3",
                    tol: "520ml*瓶",
                    price: "123.00",
                    pinglun: 3625,
                    num: 1,
                    check: false,
                    floatLeft: false
                  },
                  {
                    name: "滋养洗发水",
                   src: "../../static/classify/4.jpg",
                    id: "2",
                    tol: "520ml*瓶",
                    price: "123.00",
                    pinglun: 3625,
                    num: 1,
                    check: false,
                    floatLeft: false
                  },
                  {
                    name: "柔顺洗发露",
                    src: "../../static/classify/5.jpg",
                    id: "3",
                    tol: "520ml*瓶",
                    price: "123.00",
                    pinglun: 3625,
                    num: 1,
                    check: false,
                    floatLeft: false
                  }
                ]
              },
              {
                title: "染发类",
                itemecon: [{
                    name: "沙宣染色",
                    src: "../../static/classify/7.jpg",
                    id: "7",
                    tol: "520ml*瓶",
                    price: "123.00",
                    pinglun: 3625,
                    num: 1,
                    check: false,
                    floatLeft: false
                  },
                  {
                    name: "沙宣双氧乳",
                    src: "../../static/classify/8.jpg",
                    id: "8",
                    tol: "520ml*瓶",
                    price: "123.00",
                    pinglun: 3625,
                    num: 1,
                    check: false,
                    floatLeft: false
                  },
                  {
                    name: "沙宣染发膏",
                    src: "../../static/classify/9.jpg",
                    id: "9",
                    tol: "520ml*瓶",
                    price: "123.00",
                    pinglun: 3625,
                    num: 1,
                    check: false,
                    floatLeft: false
                  }
                ]
              }
            ]
          },
          {
            name: "海飞丝",
            content: [{
                title: "洗发类",
                itemecon: [{
                    name: "护亮泽洗发水",
                    src: "../../static/classify/1.jpg",
                    id: "1",
                    tol: "520ml*瓶",
                    price: "123.00",
                    pinglun: 3625,
                    num: 1,
                    check: false,
                    floatLeft: false
                  },
                  {
                    name: "滋养洗发水",
                    src: "../../static/classify/2.jpg",
                    id: "2",
                    tol: "520ml*瓶",
                    price: "123.00",
                    pinglun: 3625,
                    num: 1,
                    check: false,
                    floatLeft: false
                  },
                  {
                    name: "柔顺洗发露",
                    src: "../../static/classify/3.jpg",
                    id: "3",
                    tol: "520ml*瓶",
                    price: "123.00",
                    pinglun: 3625,
                    num: 1,
                    check: false,
                    floatLeft: false
                  }
                ]
              },
              {
                title: "染发类",
                itemecon: [{
                    name: "沙宣染色",
                    src: "../../static/classify/7.jpg",
                    id: "7",
                    tol: "520ml*瓶",
                    price: "123.00",
                    pinglun: 3625,
                    num: 1,
                    check: false,
                    floatLeft: false
                  },
                  {
                    name: "沙宣双氧乳",
                    src: "../../static/classify/8.jpg",
                    id: "8",
                    tol: "520ml*瓶",
                    price: "123.00",
                    pinglun: 3625,
                    num: 1,
                    check: false,
                    floatLeft: false
                  },
                  {
                    name: "沙宣染发膏",
                    src: "../../static/classify/9.jpg",
                    id: "9",
                    tol: "520ml*瓶",
                    price: "123.00",
                    pinglun: 3625,
                    num: 1,
                    check: false,
                    floatLeft: false
                  },
                  {
                    name: "滋养洗发水",
                    src: "../../static/classify/2.jpg",
                    id: "2",
                    tol: "520ml*瓶",
                    price: "123.00",
                    pinglun: 3625,
                    num: 1,
                    check: false,
                    floatLeft: false
                  },
                  {
                    name: "柔顺洗发露",
                    src: "../../static/classify/3.jpg",
                    id: "3",
                    tol: "520ml*瓶",
                    price: "123.00",
                    pinglun: 3625,
                    num: 1,
                    check: false,
                    floatLeft: false
                  }
                ]
              }
            ]
          },
          {
            name: "资生堂",
            content: [{
                title: "洗发类",
                itemecon: [{
                    name: "护亮泽洗发水",
					src: "../../static/classify/4.jpg",
                    id: "1",
                    tol: "520ml*瓶",
                    price: "123.00",
                    pinglun: 3625,
                    num: 1,
                    check: false,
                    floatLeft: false
                  },
                  {
                    name: "滋养洗发水",
                    src: "../../static/classify/2.jpg",
                    id: "2",
                    tol: "520ml*瓶",
                    price: "123.00",
                    pinglun: 3625,
                    num: 1,
                    check: false,
                    floatLeft: false
                  },
                  {
                    name: "柔顺洗发露",
                    src: "../../static/classify/5.jpg",
                    id: "3",
                    tol: "520ml*瓶",
                    price: "123.00",
                    pinglun: 3625,
                    num: 1,
                    check: false,
                    floatLeft: false
                  },
                  {
                    name: "滋养洗发水",
                    src: "../../static/classify/7.jpg",
                    id: "2",
                    tol: "520ml*瓶",
                    price: "123.00",
                    pinglun: 3625,
                    num: 1,
                    check: false,
                    floatLeft: false
                  },
                  {
                    name: "柔顺洗发露",
                    src: "../../static/classify/3.jpg",
                    id: "3",
                    tol: "520ml*瓶",
                    price: "123.00",
                    pinglun: 3625,
                    num: 1,
                    check: false,
                    floatLeft: false
                  }
                ]
              },
              {
                title: "染发类",
                itemecon: [{
                    name: "沙宣染色",
                    src: "../../static/classify/7.jpg",
                    id: "7",
                    tol: "520ml*瓶",
                    price: "123.00",
                    pinglun: 3625,
                    num: 1,
                    check: false,
                    floatLeft: false
                  },
                  {
                    name: "沙宣双氧乳",
                    src: "../../static/classify/8.jpg",
                    id: "8",
                    tol: "520ml*瓶",
                    price: "123.00",
                    pinglun: 3625,
                    num: 1,
                    check: false,
                    floatLeft: false
                  },
                  {
                    name: "沙宣染发膏",
                    src: "../../static/classify/9.jpg",
                    id: "9",
                    tol: "520ml*瓶",
                    price: "123.00",
                    pinglun: 3625,
                    num: 1,
                    check: false,
                    floatLeft: false
                  }
                ]
              }
            ]
          }
        ]
		
	
export default classfiy;