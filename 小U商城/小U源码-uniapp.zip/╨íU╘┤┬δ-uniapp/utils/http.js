import {
	baseUrl
} from './config.js'

function http(url, method = "get", data = {}) {
	return new Promise((resolve, reject) => {
		uni.request({
			url: baseUrl + url,
			method: method,
			data: data,
			success: res => {
				resolve(res)
			},
			fali: err => {
				reject(err)
			}
		})
	})
}
export {
	http
}
